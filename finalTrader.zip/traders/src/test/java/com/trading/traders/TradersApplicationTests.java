package com.trading.traders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradersApplicationTests {

	@Test
	void contextLoads() {
	}

}
